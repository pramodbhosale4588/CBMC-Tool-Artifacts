//void assert (_Bool b) {if (!b) exit();}
//int nondet_int () {int x;  return x;}
//void assume(_Bool b) { if(!b) exit();}

int x,y,v;

void main(void)
{
   v = nondet_int();
   x = v;

  x =x+1;
  y = nondet_int();
  assume(v == y);

  assert(x == y+1);
}