// cbmc ex3.c --show-vcc
// cbmc ex3.c
// cbmc ex3.c --no-assertions --show-vcc
// cbmc ex3.c --no-assertions
// cbmc ex3.c --signed-overflow-check --show-properties
//cbmc ex3.c --signed-overflow-check --show-goto-functions

void main (void)
{
 int x, y;
 x = x + y;
 if (x != 3) x = 2;
 else x++;
 assert (x <= 3);
}