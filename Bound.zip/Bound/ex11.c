// cbmc ex11.c --function sumqq --signed-overflow-check --unwind 100 --no-unwinding-assertions
// cbmc ex11.c --function sumqq --signed-overflow-check --unwind 200 --no-unwinding-assertions

int sumqq (int x)
{
 short int i, s;
 s = 0;
 for (i = 0; i <= x; i++)
 s *= i*i;
 return s;
}