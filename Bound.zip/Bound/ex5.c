// cbmc ex5.c
// cbmc ex5.c --show-properties --show-vcc

void main ()
{
 char c;
 long l;
 int i;
 l = c = i;
 assert (l==i);
}