//cbmc binsearch.c --function binsearch --unwind 140 --bounds-check
//cbmc binsearch.c --function binsearch --unwind 10 --bounds-check
//cbmc binsearch.c --function binsearch
//cbmc binsearch.c

int binsearch(int x) {
int a[16];
signed low =0; 
signed high=16;

while(low < high) {
signed middle = low + ((high - low) >> 1);

if(a[middle] < x)
  high = middle;
else if (a[middle] > x)
  low = middle + 1;
else 
  return middle;
}

return -1;
}