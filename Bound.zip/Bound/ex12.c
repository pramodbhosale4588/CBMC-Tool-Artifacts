// cbmc ex12.c
// cbmc ex12.c --function f
// cbmc ex12.c --function f --unwind 100

void f (int a)
{
	 if (a == 0)
		 assert (1);
	 else f (a - 1);
}

void main (void)
{
	 f(5);
}