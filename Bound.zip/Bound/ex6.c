//cbmc ex6.c --bounds-check --pointer-check

int puts (const char *s);
int main (int argc, char **argv)
{
 int i;
 if (argc >= 1)
 puts (argv[2]);
}