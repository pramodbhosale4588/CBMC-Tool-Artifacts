//  cbmc ex10.c --function sumq --signed-overflow-check

int sumq (void)
{
 short int i, s;
 s = 0;
 for (i = 0; i <= 10; i++)
 s *= i*i;
 return s;
}