// cbmc ex4.c
// cbmc ex4.c --function fun
// cbmc ex4.c --function fun --div-by-zero-check 

int fun (int a, int b)
{
 int c = a+b;

 if (a>0 || b>0)
 c = 1/(a+b);
 return c;
}