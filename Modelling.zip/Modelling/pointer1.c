// cbmc file1.c --show-properties --bounds-check --pointer-check
// cbmc file1.c --show-vcc --bounds-check --pointer-check
//cbmc file1.c --bounds-check --pointer-check

int puts(const char *s) 
{     }

int main(int argc, char **argv) 
{
    puts(argv[2]);
}