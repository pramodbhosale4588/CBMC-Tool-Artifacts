// Fail -  cbmc bound.c --bounds-check

int main ( void )
{
  int i,a[10],p;

    for (i=2; i<5; i++){
	a[i] = i;
         
    }

	printf("i = %d\n", a[6]);
	p = a[10034343];
	p = a[-345];
  return 0;
}


