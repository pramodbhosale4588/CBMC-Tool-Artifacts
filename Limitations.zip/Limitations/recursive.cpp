// cbmc recursive.cpp
// cbmc recursive.cpp --unwind 8

int sum(int);


int main() {
//	cout << "!!!Hello World!!!" << endl; // prints !!!Hello World!!!
	sum(0);
	return 0;
}

int sum(int n){
	while(n<8000){
		return (n + sum(n+1));
	}
}