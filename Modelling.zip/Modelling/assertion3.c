//Assertion Condition

//cbmc demo.c --show-vcc
//cbmc assertion3.c --all-claims
//cbmc assertion3.c --show-claims
//cbmc assertion3.c --slice-formula

int test_assert ( int x )
{
   assert( x <= 4 );
   return x;
}

int main ( void )
{
  int i;

    for (i=0; i<=9; i++){
        test_assert( i );
        //printf("i = %d\n", i);
    }

  return 0;
}