//cbmc negativeloop.c --show-vcc
//cbmc negativeloop.c --all-claims
//cbmc negativeloop.c --show-claims

int main ( void )
{
  int i,a[10],p;

    for (i=0; i<=-18; i++){
	a[i] = i;
         
    }

	printf("i = %d\n", a[6]);
	p = a[10034343];
  return 0;
}


