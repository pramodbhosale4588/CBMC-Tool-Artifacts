//cbmc unsignedchar.c

int main() {

unsigned char a,b;
unsigned int result = 0, i;

a = nondet_uchar();
b = nondet_uchar();

for(i=0; i<8; i++)
   if((b>>i)&1)
       result +=(a<<i);

assert(result==a*b);
}