//cbmc assertion2.c --unwind 2
//cbmc assertion2.c

int main() {
int p;  
for(int i=0; i<10; i++) {
   p = i;
  }

  assert(5);
}

