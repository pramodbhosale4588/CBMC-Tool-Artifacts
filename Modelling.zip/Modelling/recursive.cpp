// cbmc recursive.cpp
// cbmc recursive.cpp --unwind 8

int sum(int);

int main() {
	sum(0);
	return 0;
}

int sum(int n){
	while(n<8000){
		return (n + sum(n+1));
	}
}