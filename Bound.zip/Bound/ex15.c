//cbmc ex15.c --show-properties --bounds-check


int main() {
int buffer[10];
buffer[20] = 10;
}